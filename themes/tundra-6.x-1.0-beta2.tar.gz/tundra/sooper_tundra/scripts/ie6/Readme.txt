These scripts are needed for ie6 to behave the same as standards-compliant browsers.

iepngfix.htc was chosen over jQuery png fix because the latter has caused me lot's of layout troubles in the past.