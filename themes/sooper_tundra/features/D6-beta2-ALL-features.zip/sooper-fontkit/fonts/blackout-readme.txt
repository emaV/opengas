Thanks for your interest in Blackout!

HI:		I made this font in 2008 with Illustrator and Font Lab Studio, 
		both of which are wonderful. This is not based on any other 
		font and was created from scratch, although I'm sure there are 
		similarities to other fonts out there (purely coincidental). 

		It was created for my own personal portfolio (I tend to do that) 
		because I didn't want to simply fill in the holes of some favorite 
		bold fonts. "Midnight" came first, but then I realized that I was 
		tired of reversing the font color and adding a background to that 
		font, so "2 AM" was born.

USAGE: 	These fonts are not perfect. They are missing symbols and 
		characters. But they are usable, and in my opinion, very fun. 
		When using "2 AM" insert an underscore "_" to maintain a solid
		background.


LEGAL:	If you're reading this (which means you downloaded the files) 
		you've already agreed to NOT re-distribute these contents or modify
		and profit from them in any way. BUT, you can use Blackout for 
		personal or commercial purposes. I've already had enough work stolen
		or claimed as someone else's, so please, respect the original artist.
		
SHARE:  If you do end up using Blackout I'd love to see what you do with it!
		Send an email to hello@sursly.com (links please, no large attachments)
		
All Contents Copyright © Tyler Finck