$(function() {
  Cufon.replace('h1#sitename a, h1.nodetitle a', {
      hover: true
  });
  Cufon.replace(Drupal.settings.fontKit.invoke);
});